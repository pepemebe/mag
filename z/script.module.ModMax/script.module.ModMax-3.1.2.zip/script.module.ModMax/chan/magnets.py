# -*- coding: utf-8 -*-

import re, base64, requests, xbmc, xbmcgui, xbmcaddon, xbmcplugin

from os import remove
import unicodedata
import random
import sys
import filecmp
import os, time, traceback
import time, sqlite3

from urllib.parse import urlencode, urlparse, parse_qsl, quote
import json, urllib, urllib.request, urllib.parse
from os import remove

import xbmcaddon
import xbmcvfs
translatePath = xbmcvfs.translatePath

if sys.version_info[0] < 3: 
    PY3 = False
else: 
    PY3 = True


def getSetting(settingName):

    setting = xbmcaddon.Addon().getSetting(settingName)

    if setting == 'true':
        setting = True
    elif setting == 'false':
        setting = False

    return setting
    

if len(sys.argv) > 1:
    ADDON_HANDLE = int(sys.argv[1])
else:
    ADDON_HANDLE = -1

source = requests.get('https://raw.githubusercontent.com/pepemebe/mag/main/poc/ult', timeout=5).text

runtime_path_fix_max = translatePath(xbmcaddon.Addon(id="script.module.ModMax").getAddonInfo('Path')).rstrip(os.sep)
data_path_fix_max = translatePath(xbmcaddon.Addon(id="script.module.ModMax").getAddonInfo('Profile'))
        
addon_name = xbmcaddon.Addon().getAddonInfo("name")

perpage = 25
lang = 'Esp'
'''
TMDB_API_KEY = ADDON.getSetting('tmdb_api_key')
TMDB_BASE = "https://api.themoviedb.org/3"
TMDB_IMG = "https://image.tmdb.org/t/p"
'''
#DB_PATH = xbmcvfs.translatePath(f'special://userdata/addon_data/script.module.ModMax/tmdb_cache.db')
DB_PATH = os.path.join(data_path_fix_max, 'tmdb_cache.db')


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS tmdb_cache (
            cache_key TEXT PRIMARY KEY,
            data_type TEXT,           -- 'movie', 'tv', 'season', 'episode'
            tmdb_id INTEGER,
            title TEXT,
            year TEXT,
            synopsis TEXT,
            rating REAL,
            poster TEXT,
            fanart TEXT,
            season INTEGER,
            episode INTEGER,
            timestamp REAL,
            expires_at REAL
        )
    ''')
    c.execute('CREATE INDEX IF NOT EXISTS idx_key ON tmdb_cache (cache_key)')
    conn.commit()
    conn.close()

init_db()

CACHE_DAYS = 14
CACHE_SEC = CACHE_DAYS * 86400


def get_cache_key(*args):
    """Genera clave única: tipo + título + año + season + episode"""
    return "_".join(str(a) for a in args if a is not None)


def get_from_cache(key):
    TMDB_IMG = 'https://image.tmdb.org/t/p'
    conn = sqlite3.connect(DB_PATH)
    try:
        c = conn.cursor()
        c.execute("SELECT synopsis, rating, poster, fanart, year, timestamp, expires_at "
                  "FROM tmdb_cache WHERE cache_key = ?", (key,))
        row = c.fetchone()
        if row and time.time() < row[6]:
            return {
                'synopsis': row[0],
                'rating': row[1],
                'poster': f"{TMDB_IMG}/w500{row[2]}" if row[2] else '',
                'fanart': f"{TMDB_IMG}/original{row[3]}" if row[3] else '',
                'year': row[4]
            }
        else:
            None
    except sqlite3.Error as e:
        None
    finally:
        conn.close()
        
    return None


def save_to_cache(key, data_type, tmdb_id, title, year, synopsis, rating, poster, fanart, season=None, episode=None):
    try:
        now = time.time()
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''
            INSERT OR REPLACE INTO tmdb_cache 
            (cache_key, data_type, tmdb_id, title, year, synopsis, rating, poster, fanart,
             season, episode, timestamp, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (key, data_type, tmdb_id, title, year, synopsis, rating, poster, fanart, season, episode, now, now + CACHE_SEC))
        conn.commit()
    except sqlite3.Error as e:
        None
    finally:
        conn.close()


'''def dec_cod(host):
    return #tacones_close
    data = requests.get(host, timeout=5).text
    
    from Cryptodome.Cipher import AES
    from Cryptodome.Util.Padding import unpad
        
    iv = data[:16]
    key = data[16:48]
    clean_data = data[48:]
    encrypted_text = base64.b64decode(clean_data)
    cipher = AES.new(key.encode('utf-8'), AES.MODE_CBC, iv.encode('utf-8'))
    decrypted_bytes = unpad(cipher.decrypt(encrypted_text), AES.block_size)
    data = decrypted_bytes.decode('utf-8')
    
    return data'''


def check_update_titles():
    
    silent = True
    caps_txt = os.path.join(data_path_fix_max, 'caps.txt')
    bbdd_http = base64.b64decode(b'aHR0cDovL21vZG1heDAxLmR1Y2tkbnMub3JnOjUxMDAvZGVzY2FyZ2FyL2JiZGQuemlw').decode('utf-8')
    
    if not os.path.exists(caps_txt):
        localfilebbdd = os.path.join(data_path_fix_max, 'temp_bbdd.zip')

        if os.path.exists(localfilebbdd): os.remove(localfilebbdd)

        down_file_zip = requests.get(bbdd_http, stream=True)
        with open(localfilebbdd, 'wb') as fz:
            for chunk in down_file_zip.iter_content(chunk_size=128):
                fz.write(chunk)
                
        try:
            import zipfile
            dir = zipfile.ZipFile(localfilebbdd, 'r')
            dir.extractall(data_path_fix_max)
            dir.close()
        except:
            #xbmc.executebuiltin('Extract("%s", "%s")' % (localfilebbdd, data_path_fix_max))
            if not silent: 
                xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', 'Error en BBDD', xbmcgui.NOTIFICATION_INFO, 5000, False)
            time.sleep(2)
            os.remove(localfilebbdd)
            
            return mainlist(item)

        time.sleep(2)

        os.remove(localfilebbdd)
        
        if os.path.exists(caps_txt):
            if not silent:
                xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', 'BBDD actualizadas', xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            if not silent:
                xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', 'Error en BBDD', xbmcgui.NOTIFICATION_INFO, 5000, False)
            return mainlist(item)
            
        
    else:
        if not silent: 
            xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', 'BBDD comprobadas', xbmcgui.NOTIFICATION_INFO, 5000, False)
        None
    
    return


def mainlist():

    clean_expired_cache(verbose=False)

    actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
    last_xml = os.path.join(data_path_fix_max, 'last.xml')
    tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
    
    if not os.path.exists(actu_xml) or not os.path.exists(last_xml) or not os.path.exists(tvs_last_xml):
        check_update_titles()
    
    list_item_streams = xbmcgui.ListItem(label="[B][COLOR=coral]Buscar...[/COLOR][/B]")
    
    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
    thumbnail = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#translatePath("special://home/addons/script.module.ModMax/icon.png")
    poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#
    fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')#movies')
            
    info_tag = list_item_streams.getVideoInfoTag()
    info_tag.setMediaType('video')#movie')
    
    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
    list_item_streams.getVideoInfoTag().setPlot(f'[B][COLOR=cyan]·Buscador de películas y series en las BBDD.\n[/COLOR][/B]')
    
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE, 
        url=f"{sys.argv[0]}?{urlencode({'action': 'search', 'search_type': None})}",
        listitem=list_item_streams, 
        isFolder=True
    )
    
    list_item_streams = xbmcgui.ListItem(label="[B][COLOR=deepskyblue]Cine destacado[/COLOR][/B]")
    
    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
    thumbnail = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#translatePath("special://home/addons/script.module.ModMax/icon.png")
    poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#
    fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')#movies')
            
    info_tag = list_item_streams.getVideoInfoTag()
    info_tag.setMediaType('video')#movie')
    
    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
    list_item_streams.getVideoInfoTag().setPlot(f'[B][COLOR=cyan]·Muestra una selección de películas lanzadas recientemente.\n[/COLOR][/B]')
    
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE, 
        url=f"{sys.argv[0]}?{urlencode({'action': 'selection', 'search_type': 'movie'})}",
        listitem=list_item_streams, 
        isFolder=True
    )

    try:
        actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        
        if os.path.exists(actu_xml) == True and os.path.exists(last_xml) == True:
            
            list_item_streams = xbmcgui.ListItem(label="[B][COLOR=deepskyblue]Últimas películas añadidas[/COLOR][/B]")
    
            iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
            thumbnail = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#translatePath("special://home/addons/script.module.ModMax/icon.png")
            poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#
            fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
            xbmcplugin.setContent(ADDON_HANDLE, 'videos')#movies')
            
            info_tag = list_item_streams.getVideoInfoTag()
            info_tag.setMediaType('video')#movie')
            
            list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
            list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
            list_item_streams.getVideoInfoTag().setPlot(f'[B][COLOR=cyan]·Muestra una lista de películas que se han actualizado recientemente.\n[/COLOR][/B]')
    
            xbmcplugin.addDirectoryItem(
                handle=ADDON_HANDLE, 
                url=f"{sys.argv[0]}?{urlencode({'action': 'last', 'search_type': 'movie'})}",
                listitem=list_item_streams, 
                isFolder=True
            )
        else:
            None
    except:
        None
    
    list_item_streams = xbmcgui.ListItem(label="[B][COLOR=hotpink]Últimos capítulos añadidos[/COLOR][/B]")
    
    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
    thumbnail = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#translatePath("special://home/addons/script.module.ModMax/icon.png")
    poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"#
    fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')#tvshows')
            
    info_tag = list_item_streams.getVideoInfoTag()
    info_tag.setMediaType('video')#tvshow')
    
    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
    list_item_streams.getVideoInfoTag().setPlot(f'[B][COLOR=cyan]·Muestra una lista de series con las temporadas y episodios actualizados recientemente.\n[/COLOR][/B]')
    
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE, 
        url=f"{sys.argv[0]}?{urlencode({'action': 'last_tvshow', 'search_type': 'tvshow'})}",
        listitem=list_item_streams, 
        isFolder=True
    )
    
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)#, updateListing=True, cacheToDisc=False)


def last(params):

    next_page = params.get('next_page', '')
    if next_page: 
        page = int(next_page)
    else:
        page = 0
    
    auxlist = set()
    lenlist = set()

    try:
        actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
        with open (actu_xml, 'r', encoding='utf-8') as actu:
            dat1 = actu.read()
        if not dat1:
            check_update_titles()
            actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
            with open (actu_xml, 'r', encoding='utf-8') as actu:
                dat1 = actu.read()
    except:
        check_update_titles()
        actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
        with open (actu_xml, 'r', encoding='utf-8') as actu:
            dat1 = actu.read()
        if not dat1:
            check_update_titles()
            actu_xml = os.path.join(data_path_fix_max, 'actu.xml')
            with open (actu_xml, 'r', encoding='utf-8') as actu:
                dat1 = actu.read()

    dat1 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat1)
    patro1 = r'<title>([^<]+)</'
    
    for tit in re.compile(patro1, re.DOTALL).findall(dat1):
        title = normalizar(tit)
        if not title in auxlist:
            auxlist.add(title)

    try:
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            dat2 = last.read()
        if not dat2:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                dat2 = last.read()
    except:
        check_update_titles()
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            dat2 = last.read()
        if not dat2:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                dat2 = last.read()

    dat2 = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", dat2)
    patro2 = r'<item.*?<title>([^<]+)</.*?<micro(.*?)<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<info>([^<]+)</'

    desde = page * perpage
    hasta = desde + perpage
    ilist = 0

    for tit, calidades, poster, fanart, year, plot in re.compile(patro2, re.DOTALL).findall(dat2):
        
        title = normalizar(tit)
        cals = qualities(calidades)
        rating = 0

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        '''else:
            cal0 = [*cals]'''
        cal0.reverse()
        
        if not title in auxlist:
            
            ilist += 1
            if desde < ilist <= hasta:
                
                lenlist.add(title)
        
                cals_json = cals
                qlt_json = json.dumps(cals_json, ensure_ascii=False)
                qlt_encoded = quote(qlt_json)
                
                list_item_streams = xbmcgui.ListItem(label=title + f' [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]' + f' [COLOR=limegreen]{ cal0 }[/COLOR]')
            
                tmdb_id = None
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title, year, tmdb_id)
                
                if plot_tmdb:
                    if plot_tmdb != None:
                        if plot_tmdb != '':
                            plot = plot_tmdb
                if year_tmdb:
                    year = year_tmdb
                if poster_tmdb:
                    poster = poster_tmdb
                if fanart_tmdb:
                    fanart = fanart_tmdb
                if rating_tmdb:
                    rating = rating_tmdb
            
                iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
                info_tag = list_item_streams.getVideoInfoTag()
                info_tag.setMediaType('movie')#video')
                info_tag.setTitle(title)
            
                list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
                list_item_streams.getVideoInfoTag().setFirstAired(year)
                list_item_streams.getVideoInfoTag().setRating(rating)
            
                list_item_streams.setProperty("IsPlayable", "True")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE,
                    url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'uris': qlt_encoded, 'infoLabels': {'year': year, 'plot': plot}, 'type': 'movie', 'contentTitle': title, 'contentType': 'movie', 'tmdb_id': tmdb_id, 'rating': rating})}",
                    listitem=list_item_streams, 
                    isFolder=False
                )
    
    if len(lenlist) == 0:
        
        selection(params)

    else:
        None

    if ilist > hasta:
        next_page = page + 1
        
        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=coral]>> Página siguiente[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        #poster = translatePath("special://home/addons/script.module.ModMax/icon.png")
        poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]Siguiente página[/COLOR]')
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'last', 'next_page': next_page})}",
            listitem=list_item_streams, 
            isFolder=True
        )
    
    #xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    #xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)#, updateListing=True, cacheToDisc=False)


def extrainfo(query, data_tvs, tmdb_id):#, n):

    try:
        year = None
        plot, year, poster, fanart, rating = fetch_tmdb_tv_metadata(query, year, tmdb_id)
        
        if plot and year and poster and fanart and rating:
            
            return fanart, poster, plot, year, rating
        
    except:
        None

    data = data_tvs
    patron = r'<title>([^<]+)</.*?<info>([^<]+)</.*?<year>([^<]+)</.*?thumb="([^"]+)".*?fanart="([^"]+)"'
    
    matches = re.compile(patron, re.DOTALL).findall(data)
    
    for tit, plot, year, poster, fanart in matches:
        title = normalizar(tit.strip())
        
        titl1 = re.sub(r"\'|:|-|\.|,|¿|\?", "", title)
        quer1 = re.sub(r"\'|:|-|\.|,|¿|\?", "", query)
        
        if quer1 == titl1:
            
            fanart = fanart
            poster = poster
            plot = plot
            year = year#f'[COLOR=grey]({year})[/COLOR]'
            rating = 0
            
            return fanart, poster, plot, year, rating
        
        elif quer1 in titl1 and quer1 != 'Los Bridgerton':
            
            fanart = fanart
            poster = poster
            plot = plot
            year = year#f'[COLOR=grey]({year})[/COLOR]'
            rating = 0
            
            return fanart, poster, plot, year, rating
            
        else:
            
            fanart = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
            poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
            plot = 'Sin datos.'
            year = ''
            rating = 0
            
    return fanart, poster, plot, year, rating


def last_tvshow(params):

    next_page = params.get('next_page', '')
    if next_page: 
        page = int(next_page)
    else:
        page = 0
    
    title_search = []
    caps_txt = os.path.join(data_path_fix_max, 'caps.txt')
    
    if os.path.exists(caps_txt) == False:
        check_update_titles()
        
        with open (caps_txt, 'r', encoding='utf-8') as caps:
            data = caps.read()
    else:
        with open (caps_txt, 'r', encoding='utf-8') as caps:
            data = caps.read()
    
    try:
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data_tvs = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data_tvs = tvs_last.read()
    except:
        check_update_titles()
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data_tvs = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data_tvs = tvs_last.read()
    
    patron = r'[0-9]{1,},.?([0-9]{3,}),([^,]+),([^,]+),([^\n]+)\n'
    #n = 1

    desde = page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tmdb_id, tit, season, episode in re.compile(patron, re.DOTALL).findall(data):
        
        ilist += 1
        if desde < ilist <= hasta:
            
            title = normalizar(tit.strip())
            if tmdb_id == '1610413':
                year = ''
                plot, year, poster, fanart, rating = fetch_tmdb_metadata(title, year, tmdb_id)
            else:
                
                try:
                    fanart, poster, plot, year, rating = extrainfo(title, data_tvs, tmdb_id)#, n)
                    if not rating:
                        try:
                            year = ''
                            plot, year, poster, fanart, rating = fetch_tmdb_metadata(title, year, tmdb_id)
                        except:
                            None
                except:
                    year = ''
                    plot, year, poster, fanart, rating = fetch_tmdb_metadata(title, year, tmdb_id)
            #n += 1
        
            temp = season.strip().split(' ')[0].strip()
        
            if 'final' in episode.lower() or 'completa' in episode.lower():
                leg = ' -Completa-'
            else:
                leg = ''
            if ' reparado' in tit:
                title = re.sub(r" Reparado", " [COLOR=yellow](Reparado)[/COLOR]", title)
                tit = re.sub(r" reparado", "", tit)
            if ' mobland' in tit:
                title = re.sub(r" mobland", "(Mobland)", tit)
                tit = re.sub(r" mobland", "(mobland)", tit)
            try:
                epi = episode.strip().split(' ')[1].strip()
            except:
                if not 'episodio' in episode.lower():
                    epi = 'Temporada Completa'
                else:
                    epi = '?'
        
            list_item_streams = xbmcgui.ListItem(label=f'[COLOR=hotpink][{temp}x{epi}][/COLOR] {title}[COLOR=hotpink] ({year[:4]}) {leg}[/COLOR]')
            
            iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
            thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
            #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
            #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
            xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
            info_tag = list_item_streams.getVideoInfoTag()
            info_tag.setMediaType('tvshow')#video')
            info_tag.setTitle(title)
            
            list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
            list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
            list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
            list_item_streams.getVideoInfoTag().setFirstAired(year)
            list_item_streams.getVideoInfoTag().setRating(rating)
            
            #list_item_streams.setProperty("IsPlayable", "True")
            xbmcplugin.addDirectoryItem(
                handle=ADDON_HANDLE,
                url=f"{sys.argv[0]}?{urlencode({'action': 'search_tvshow', 'title_search': title, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id, 'rating': rating})}",
                listitem=list_item_streams, 
                isFolder=True
            )

    if ilist > hasta:
        next_page = page + 1
        
        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=coral]>> Página siguiente[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")

        #poster = translatePath("special://home/addons/script.module.ModMax/icon.png")
        poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
        xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]Siguiente página[/COLOR]')
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'last_tvshow', 'next_page': next_page})}",
            listitem=list_item_streams, 
            isFolder=True
        )
    
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)#, updateListing=True, cacheToDisc=False)


def qualities(calidades):

    if not '&gt;' in calidades:
        
        cal1 = re.search(r'hd>([^<]+)</', calidades)
        
        try:
            cal1 = cal1.group(1)
        except:
            cal1 = 'NA'
        
        cal2 = re.search(r'<fullhd>([^<]+)</', calidades)
        
        try:
            cal2 = cal2.group(1)
        except:
            cal2 = 'NA'
        
        cal3 = re.search(r'<tresd>([^<]+)</', calidades)
        try:
            cal3 = cal3.group(1)
        except:
            cal3 = 'NA'
        
        cal4 = re.search(r'<cuatrok>([^<]+)<', calidades)
        
        try:
            cal4 = cal4.group(1)
        except:
            cal4 = 'NA'
        
    else:
        
        cal1 = re.search(r'hd&gt;([^&]+)&lt;/', calidades)
        cal1 = cal1.group(1)
        cal2 = re.search(r'&lt;fullhd&gt;([^&]+)&lt;/', calidades)
        cal2 = cal2.group(1)
        cal3 = re.search(r'&lt;tresd&gt;([^&]+)&lt;/', calidades)
        cal3 = cal3.group(1)
        cal4 = re.search(r'&lt;cuatrok&gt;([^&]+)&lt;', calidades)
        cal4 = cal4.group(1)

    cals = {}

    if cal1 != 'NA':
        cals['MicroHD'] = cal1
    if cal2 != 'NA':
        cals['FullHD'] = cal2
    if cal3 != 'NA':
        cals['3D'] = cal3
    if cal4 != 'NA':
        cals['4K'] = cal4

    return cals


def normalizar(t):

    t = re.sub(r"0N", "ON", t)
    t = re.sub(r" PANTER", " PANTHER", t)
    t = re.sub(r"NWE", "NEW", t)

    if t == 'FURIA':
        t = 'FURIA (2025)'
    elif t == 'BABY':
        t = 'BABY (DEL TEMOR AL AMOR)'
    elif t == 'DESTINO FATAL II':
        t = 'DESTINO FINAL II'
    elif t == 'DESTINO FINAL V':
        t = 'DESTINO FINAL V (5)'
    elif t == 'ERASE UNA VEZ DEADPOOL':
        t = 'ÉRASE UNA VEZ UN DEADPOOL'
    elif t == 'OLD BOY':
        t = 'OLDBOY'
    elif t == 'WONDER':
        t = 'WONDER (EXTRAORDINARIO)'
    elif t.lower() == 'cobra kei':
        t = 'Cobra Kai'
    elif t.lower() == 'lockerbie un busqueda de la verdad':
        t = 'lockerbie: en busqueda de la verdad'
    elif t.lower() == 'adolescente':
        t = 'adolescencia'
    elif t.lower() == 'el alcon maltes':
        t = 'el halcon maltes'
    
    if "(SD)" in t or "( sd)" in t or "( sd )" in t or "( 1994 )" in t:
        t = re.sub(r"\(SD\)|\( sd\)|\( sd \)|\( 1994 \)", "", t)
    t = re.sub(r"&amp;", "AND", t)

    if PY3 == False:
        t = re.sub(r"Á", "A", t)
        t = re.sub(r"É", "E", t)
        t = re.sub(r"Í", "I", t)
        t = re.sub(r"Ó", "O", t)
        t = re.sub(r"Ú", "U", t)

    if PY3 == False:
        t = re.sub(r"á", "a", t)
        t = re.sub(r"é", "e", t)
        t = re.sub(r"í", "i", t)
        t = re.sub(r"ó", "o", t)
        t = re.sub(r"ú", "u", t)

    t = t.strip().title()

    if PY3 == False:
        t = re.sub(r"ÑA", "ña", t)
        t = re.sub(r"ÑE", "ñe", t)
        t = re.sub(r"ÑI", "ñi", t)
        t = re.sub(r"ÑO", "ño", t)
        t = re.sub(r"ÑU", "ñu", t)

        t = re.sub(r"ñA", "ña", t)
        t = re.sub(r"ñE", "ñe", t)
        t = re.sub(r"ñI", "ñi", t)
        t = re.sub(r"ñO", "ño", t)
        t = re.sub(r"ñU", "ñu", t)
    
    return t


def search_tvshow(params):

    title_search = params.get('title_search', '')
    tmdb_id = params.get('tmdb_id', '')
    fanart_tmdb = params.get('fanart', '')
    poster_tmdb = params.get('poster', '')
    rating_tmdb = params.get('rating', '')
    
    try:
        info = eval(params.get('infoLabels', ''))
    except:
        info = params.get('infoLabels', '')
    
    plot_tmdb = info['plot']
    year_tmdb = info['year']
    
    next_page = params.get('next_page', '')
    if next_page: 
        page = int(next_page)
    else:
        page = 0
    lab = params.get('lab', '')
    if lab: 
        lab = ''
    else:
        lab = 'last_tvs'

    try:
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data = tvs_last.read()
    except:
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data = tvs_last.read()

    patron = r'<title>([^<]+)</.*?<info>([^<]+)</.*?<year>([^<]+)</.*?<genre>([^<]+)</.*?<seasons>(.*?)</seasons>'
    
    matches = re.compile(patron, re.DOTALL).findall(data)

    patron_title = r'<title>([^<]+)</'
    matches_title = re.compile(patron_title, re.DOTALL).findall(data)
    title_list = 0
    for tit2 in matches_title:
        title2 = normalizar(tit2)
        if title_search.lower().strip() in title2.lower().strip():
            title_list += 1
    
    desde = page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, plot, year, genre, seas in matches:
    
        year_ori = year
        rating = 0
        
        if plot_tmdb:
            if plot_tmdb != None:
                    if plot_tmdb != '':
                        plot = plot_tmdb
        if year_tmdb:
            year = year_tmdb
        if poster_tmdb:
            poster = poster_tmdb
        if fanart_tmdb:
            fanart = fanart_tmdb
        if rating_tmdb:
            rating = rating_tmdb

        title = normalizar(tit)
        title_search = normalizar(title_search)

        if lab == 'last_tvs':
            title = re.sub(r"\'|:|-|\.|,|¿|\?", "", title)
            title_search = re.sub(r"\'|:|-|\.|,|¿|\?", "", title_search)

            if title_list > 1:
                if title_search.lower().strip() in title.lower().strip():
                    ilist += 1
                    if  desde < ilist <= hasta:
                        
                        list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year_ori})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                        #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                        #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                        xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                        info_tag = list_item_streams.getVideoInfoTag()
                        info_tag.setMediaType('tvshow')#video')
                        info_tag.setTitle(title)
            
                        
                        if title_search.lower().strip() != title.lower().strip():
                            tmdb_id = None
                            plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year_ori, tmdb_id)
                            #tmdb_id = None
                            
                        elif title_search.lower().strip() == title.lower().strip():
                            plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id)
                            #tmdb_id = None
        
                        if plot_tmdb:
                            if plot_tmdb != None:
                                if plot_tmdb != '':
                                    plot = plot_tmdb
                        if year_tmdb:
                            year = year_tmdb
                        if poster_tmdb:
                            poster = poster_tmdb
                        if fanart_tmdb:
                            fanart = fanart_tmdb
                        if rating_tmdb:
                            rating = rating_tmdb
                            
                        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                        list_item_streams.getVideoInfoTag().setFirstAired(year)
                        if title != 'La Casa De Papel El Fenomeno':
                            list_item_streams.getVideoInfoTag().setRating(rating)
            
                        #list_item_streams.setProperty("IsPlayable", "True")
                        xbmcplugin.addDirectoryItem(
                            handle=ADDON_HANDLE,
                            url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title})}",#, 'tmdb_id': tmdb_id})}",#
                            listitem=list_item_streams, 
                            isFolder=True
                        )

            elif title_search.lower().strip() == title.lower().strip():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    params = {'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id}
                    
                    return seasons(params)

            elif ''.join((c for c in unicodedata.normalize('NFD', title_search.lower()) if unicodedata.category(c) != 'Mn')) == title.lower().strip():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#video')
                    info_tag.setTitle(title)
            
                    plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id)
        
                    if plot_tmdb:
                        if plot_tmdb != None:
                            if plot_tmdb != '':
                                plot = plot_tmdb
                    if year_tmdb:
                        year = year_tmdb
                    if poster_tmdb:
                        poster = poster_tmdb
                    if fanart_tmdb:
                        fanart = fanart_tmdb
                    if rating_tmdb:
                        rating = rating_tmdb
            
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    #list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE,
                        url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=True
                    )

            else:
                title = re.sub(r"\'|:|-|\.", "", title)
                title_search = re.sub(r"\'|:|-|\.", "", title_search)
                if title_search.lower().strip() in title.lower().strip():
                    ilist += 1
                    if  desde < ilist <= hasta:
                        
                        list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                        #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                        #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                        xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                        info_tag = list_item_streams.getVideoInfoTag()
                        info_tag.setMediaType('tvshow')#video')
                        info_tag.setTitle(title)
            
                        plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id)
        
                        if plot_tmdb:
                            if plot_tmdb != None:
                                if plot_tmdb != '':
                                    plot = plot_tmdb
                        if year_tmdb:
                            year = year_tmdb
                        if poster_tmdb:
                            poster = poster_tmdb
                        if fanart_tmdb:
                            fanart = fanart_tmdb
                        if rating_tmdb:
                            rating = rating_tmdb
            
                        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                        list_item_streams.getVideoInfoTag().setFirstAired(year)
                        list_item_streams.getVideoInfoTag().setRating(rating)
            
                        #list_item_streams.setProperty("IsPlayable", "True")
                        xbmcplugin.addDirectoryItem(
                            handle=ADDON_HANDLE,
                            url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                            listitem=list_item_streams, 
                            isFolder=True
                        )

        elif lab == 'a':
            if title[0].lower() in title_search.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#video')
                    info_tag.setTitle(title)
                    
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    #list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE,
                        url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=True
                    )

        elif lab == 'y':
            if title_search.upper() == year.upper():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#video')
                    info_tag.setTitle(title)
            
                    #plot, year, poster, fanart = fetch_tmdb_metadata(title, year, tmdb_id)
            
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    #list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE,
                        url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=True
                    )

        elif lab == 'g':
            if PY3 == True:
                genre = ''.join((c for c in unicodedata.normalize('NFD', genre.title()) if unicodedata.category(c) != 'Mn'))
            if normalizar(title_search).lower() in normalizar(genre).lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#video')
                    info_tag.setTitle(title)
            
                    #plot, year, poster, fanart = fetch_tmdb_metadata(title, year, tmdb_id)
            
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    #list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE,
                        url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=True
                    )

        else:
            if normalizar(title_search).lower() in title.lower():
                ilist += 1
                if  desde < ilist <= hasta:
                    
                    list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]')
            
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#video')
                    info_tag.setTitle(title)
            
                    #plot, year, poster, fanart = fetch_tmdb_metadata(title, year, tmdb_id)
            
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    #list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE,
                        url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=True
                    )

    if ilist != 0:
        try:
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data = tvs_last.read()
                if os.path.exists(act3_xml):
                    remove(act3_xml)
                with open(act3_xml, 'a', encoding='utf-8') as act3:
                    act3.write(data)
        except:
            None

    if ilist > hasta:
        next_page = page + 1
        
        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=coral]>> Página siguiente[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]Siguiente página[/COLOR]')
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'search_tvshow', 'title_search': title, 'next_page': next_page})}",
            listitem=list_item_streams, 
            isFolder=True
        )

    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def seasons(params):

    seas = params.get('seasons', '')
    data = seas
    if not '<\/season>$' in data:
        data = seas + '</season>'
        
    title_tvs = params.get('title_search', '')
    try:
        tmdb_id = params.get('tmdb_id', '') #None#
    except:
        None
    
    try:
        info = eval(params.get('infoLabels', ''))
    except:
        info = params.get('infoLabels', '')
    
    year = info['year'] #if title_tvs != 'Los Bridgerton' else ''
    plot = info['plot']
        
    fanart = params.get('fanart', '')
    poster = params.get('poster', '')
        
    patron = r'<season.id="([\d]+)"(.*?)</season>'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for season, data_post in matches:
        rating = 0
        title=f'Temporada {season}'
        if tmdb_id == '1610413':
            plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title_tvs, year, tmdb_id)
        else:
            
            try:
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title_tvs, year, tmdb_id, season)
            except:
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title_tvs, year, tmdb_id)
                
                
        if plot_tmdb:
            if plot_tmdb != None:
                if plot_tmdb != '':
                    plot = plot_tmdb
        if year_tmdb:
            year = year_tmdb
        if poster_tmdb:
            poster = poster_tmdb
        if fanart_tmdb:
            fanart = fanart_tmdb
        if rating_tmdb:
            rating = rating_tmdb
        
        if len(matches) == 1:
            xbmcgui.Dialog().notification(title_tvs, f"solo [COLOR tan]{title}[/COLOR]", xbmcgui.NOTIFICATION_INFO, 3000, False)
            params = {'action': 'episodes', 'episodes_data': data_post, 'title': title_tvs, 'year': year, 'num_season': season, 'fanart': fanart, 'poster': poster, 'plot': plot, 'tmdb_id': tmdb_id}
            return episodes(params)

        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=tan]{title}[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
        info_tag = list_item_streams.getVideoInfoTag()
        info_tag.setMediaType('tvshow')#video')
        info_tag.setTitle(title)
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
        list_item_streams.getVideoInfoTag().setFirstAired(year)
        list_item_streams.getVideoInfoTag().setRating(rating)
            
        #list_item_streams.setProperty("IsPlayable", "True")
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'episodes', 'title': title_tvs, 'year': year, 'episodes_data': data_post, 'num_season': season, 'contentType': 'season', 'contentSeason': season, 'fanart': fanart, 'poster': poster, 'plot': plot, 'tmdb_id': tmdb_id})}",
            listitem=list_item_streams, 
            isFolder=True
        )

    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def episodes(params):

    data_post = params.get('episodes_data', '')
    data = data_post
    season = params.get('num_season', '')    
    tmdb_id = params.get('tmdb_id', '') #None#
    title = params.get('title', '')
    year = params.get('year', '')
    
    fanart = params.get('fanart', '')
    poster = params.get('poster', '')
    plot = params.get('plot', '')

    patron = r'<episode.id="\d+".name="([^"]+)".*?link="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for num_epi, url in matches:
        
        if ' al ' in num_epi: 
            num_epi = re.sub(r' al ', ' AL ', num_epi)
        if ' A ' in num_epi:
            try:
                cap = num_epi.split(' ')[0].strip()
                if str(cap) + ' A ' in num_epi:
                    try:
                        cap_fi = num_epi.split(' A ')[1].strip()
                        clean_cap_fi = cap_fi.split(' ')[0].strip()
                        pat = r'[0-9]{1,}'
                        match = re.compile(pat, re.DOTALL).findall(clean_cap_fi)
                        if match:
                            #if clean_cap_fi == r'[0-9]{1,}':
                            num_epi = re.sub(r"%s A %s" % (str(cap), str(clean_cap_fi)), r"%s AL %s" % (str(cap), str(clean_cap_fi)), num_epi)
                    except:
                        None
            except:
                None

        elif ' Y ' in num_epi:
            try:
                cap = num_epi.split(' ')[0].strip()
                if str(cap) + ' Y ' in num_epi:
                    try:
                        cap_fi = num_epi.split(' Y ')[1].strip()
                        clean_cap_fi = cap_fi.split(' ')[0].strip()
                        pat = r'[0-9]{1,}'
                        match = re.compile(pat, re.DOTALL).findall(clean_cap_fi)
                        if match:
                            num_epi = re.sub(r"%s Y %s" % (str(cap), str(clean_cap_fi)), r"%s AL %s" % (str(cap), str(clean_cap_fi)), num_epi)
                    except:
                        None
            except:
                None
        
        if ' AL ' in num_epi:
            try:
                num_epi_0 = num_epi.split(' AL ')[0].strip()
                num_epi_1 = num_epi.split(' AL ')[1].strip()

                if ' ' or '[A-Z]' in num_epi_0:
                    num_epi_0 = re.sub(r" |[A-Z]|\(.*?\)", "", num_epi_0)
                if ' ' or '[A-Z]' in num_epi_1:
                    num_epi_1 = re.sub(r" |[A-Z]|\(.*?\)", "", num_epi_1)
            except:
                None

        if ' AL ' in num_epi and num_epi_0 != '' and num_epi_1 != '':
            
            try:
                multi_epi = num_epi
                multi_episodes = range(int(num_epi_0), int(num_epi_1) + 1)
                
                for n in multi_episodes:
                    #num_epi = '%s[COLOR=coral] [Episodios del %s][/COLOR]' % (str(n), multi_epi)
                    rating = 0
                    plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id, season, n)
                
                    if plot_tmdb:
                        if plot_tmdb != None:
                            if plot_tmdb != '':
                                plot = plot_tmdb
                    if year_tmdb:
                        year = year_tmdb
                    if poster_tmdb:
                        poster = poster_tmdb
                    if fanart_tmdb:
                        fanart = fanart_tmdb
                    if rating_tmdb:
                        rating = rating_tmdb
                        
                    url = url

                    list_item_streams = xbmcgui.ListItem(label=f'[COLOR=white]{season}x{num_epi}[/COLOR]')#um_epi}[/COLOR]')#
    
                    iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                    #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                    xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                    info_tag = list_item_streams.getVideoInfoTag()
                    info_tag.setMediaType('tvshow')#movie')#video')
                    #info_tag.setTitle(title)
            
                    list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                    list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                    list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
                    list_item_streams.getVideoInfoTag().setFirstAired(year)
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                    list_item_streams.setProperty("IsPlayable", "True")
                    xbmcplugin.addDirectoryItem(
                        handle=ADDON_HANDLE, 
                        url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'links': url, 'contentType': 'episode', 'contentSeason': season, 'contentEpisodeNumber': num_epi, 'tmdb_id': tmdb_id})}",
                        listitem=list_item_streams, 
                        isFolder=False
                    )
                    
            except:
                num_epi_0 = num_epi.split(' ')[0].strip()
                rating = 0
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id, season, num_epi_0)
                
                if plot_tmdb:
                    if plot_tmdb != None:
                        if plot_tmdb != '':
                            plot = plot_tmdb
                if year_tmdb:
                    year = year_tmdb
                if poster_tmdb:
                    poster = poster_tmdb
                if fanart_tmdb:
                    fanart = fanart_tmdb
                if rating_tmdb:
                    rating = rating_tmdb
                
                list_item_streams = xbmcgui.ListItem(label=f'[COLOR=white]{season}x{normalizar(num_epi)}[/COLOR]')
    
                iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                info_tag = list_item_streams.getVideoInfoTag()
                info_tag.setMediaType('tvshow')#movie')#video')
                #info_tag.setTitle(title)
            
                list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
                list_item_streams.getVideoInfoTag().setFirstAired(year)
                list_item_streams.getVideoInfoTag().setRating(rating)
            
                list_item_streams.setProperty("IsPlayable", "True")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE, 
                    url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'links': url, 'contentType': 'episode', 'contentSeason': season, 'contentEpisodeNumber': num_epi, 'tmdb_id': tmdb_id})}",
                    listitem=list_item_streams, 
                    isFolder=False
                )

        else:
            num_epi_0 = num_epi.split(' ')[0].strip()
            rating = 0
            if tmdb_id == '1610413':
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title, year, tmdb_id)
            else:
                
                try:
                    plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id, season, num_epi_0)
                except:
                    plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title, year, tmdb_id)
                
            if plot_tmdb:
                if plot_tmdb != None:
                    if plot_tmdb != '':
                        plot = plot_tmdb
            if year_tmdb:
                year = year_tmdb
            if poster_tmdb:
                poster = poster_tmdb
            if fanart_tmdb:
                fanart = fanart_tmdb
            if rating_tmdb:
                rating = rating_tmdb
            
            list_item_streams = xbmcgui.ListItem(label=f'[COLOR=white]{season}x{normalizar(num_epi)}[/COLOR]')
    
            iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
            thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
            #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
            #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
            xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
            info_tag = list_item_streams.getVideoInfoTag()
            info_tag.setMediaType('tvshow')#movie')#video')
            #info_tag.setTitle(title)
            
            list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
            list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
            list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
            list_item_streams.getVideoInfoTag().setFirstAired(year)
            list_item_streams.getVideoInfoTag().setRating(rating)
            
            list_item_streams.setProperty("IsPlayable", "True")
            xbmcplugin.addDirectoryItem(
                handle=ADDON_HANDLE, 
                url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'links': url, 'contentType': 'episode', 'contentSeason': season, 'contentEpisodeNumber': num_epi, 'tmdb_id': tmdb_id})}",
                listitem=list_item_streams, 
                isFolder=False
            )
    
    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def search_com(params):

    next_page = params.get('next_page', '')
    if next_page: 
        page = int(next_page)
    else:
        page = 0
        
    query_net = params.get('query_net', '')

    try:
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            data = last.read()
        if not data:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                data = last.read()
    except:
        check_update_titles()
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            data = last.read()
        if not data:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                data = last.read()
        
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<genre>([^<]+)</.*?<info>([^<]+)</'
    
    matches = re.compile(patron, re.DOTALL).findall(data)

    desde = page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, calidades, poster, fanart, year, genre, plot in matches:
        
        rating = 0
        title = normalizar(tit)
        tit2 = normalizar(tit)
        query_net = normalizar(query_net)
        cals = qualities(calidades)
        plus = '[COLOR=deepskyblue] -Película-[/COLOR]'
        
        if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
            cals['SD'] = cals['MicroHD'] #cals = 'SD'
            del cals['MicroHD'] 

        #if PY3 == False:
        x = cals.keys()
        cal0 = []
        for it in x:
            cal0.append(it)
        #else:
        #    cal0 = [*cals]
        cal0.reverse()
        
        if normalizar(query_net).lower() in title.lower():
            ilist += 1
            if desde < ilist <= hasta:
            
                cals_json = cals # f'{"uris": {cals}}'
                qlt_json = json.dumps(cals_json, ensure_ascii=False)
                qlt_encoded = quote(qlt_json)
            
                list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]  [COLOR=limegreen]{ cal0 }[/COLOR] {plus}')
            
                tmdb_id = None
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title, year, tmdb_id)
                
                if plot_tmdb:
                    if plot_tmdb != None:
                        if plot_tmdb != '':
                            plot = plot_tmdb
                if year_tmdb:
                    year = year_tmdb
                if poster_tmdb:
                    poster = poster_tmdb
                if fanart_tmdb:
                    fanart = fanart_tmdb
                if rating_tmdb:
                    rating = rating_tmdb
    
                iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
                info_tag = list_item_streams.getVideoInfoTag()
                info_tag.setMediaType('movie')#video')
                info_tag.setTitle(title)
            
                list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                #list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
                list_item_streams.getVideoInfoTag().setFirstAired(year)
                list_item_streams.getVideoInfoTag().setRating(rating)
            
                list_item_streams.setProperty("IsPlayable", "True")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE,
                    url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'uris': qlt_encoded, 'infoLabels': {'year': year, 'plot': plot}, 'type': 'movie', 'contentTitle': title, 'contentType': 'movie', 'rating': rating})}",
                    listitem=list_item_streams, 
                    isFolder=False
                )
    
    try:
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data = tvs_last.read()
    except:
        check_update_titles()
        tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
        with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
            data = tvs_last.read()
        if not data:
            check_update_titles()
            tvs_last_xml = os.path.join(data_path_fix_max, 'tvs_last.xml')
            with open (tvs_last_xml, 'r', encoding='utf-8') as tvs_last:
                data = tvs_last.read()

    patron = r'<title>([^<]+)</.*?<info>([^<]+)</.*?<year>([^<]+)</.*?<genre>([^<]+)</.*?' \
             '<thumb>([^<]+)</.*?<fanart>([^<]+)</.*?<seasons>(.*?)</seasons>'
    
    matches = re.compile(patron, re.DOTALL).findall(data)
    
    
    for tit, plot, year, genre, poster, fanart, seas in matches:

        rating = 0
        tmdb_id = None
        title = normalizar(tit)
        plus = '[COLOR=hotpink] -Serie-[/COLOR]'

        if normalizar(query_net).lower() in title.lower():
            ilist += 1
            if desde < ilist <= hasta:
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_tv_metadata(title, year, tmdb_id)
            
                if plot_tmdb:
                    if plot_tmdb != None:
                        if plot_tmdb != '':
                            plot = plot_tmdb
                if year_tmdb:
                    year = year_tmdb
                if poster_tmdb:
                    poster = poster_tmdb
                if fanart_tmdb:
                    fanart = fanart_tmdb
                if rating_tmdb:
                    #if rating != None:
                    rating = rating_tmdb
            
                #year = f'({year})'
                
                if title.lower() == 'furia (2025)':
                    title = title.split('(')[0].strip()
            
                list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year[:4]})[/COLOR] [COLOR=red]{lang}[/COLOR] {plus}')
            
                iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                #poster = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')
            
                info_tag = list_item_streams.getVideoInfoTag()
                info_tag.setMediaType('tvshow')#video')
                info_tag.setTitle(title)
                            
                list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan] {plot}[/COLOR]')
                list_item_streams.getVideoInfoTag().setFirstAired(year)
                if title != 'La Casa De Papel El Fenomeno':
                    list_item_streams.getVideoInfoTag().setRating(rating)
            
                #list_item_streams.setProperty("IsPlayable", "True")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE,
                    url=f"{sys.argv[0]}?{urlencode({'action': 'seasons', 'title_search': title, 'seasons': seas, 'infoLabels': {'year': year, 'plot': plot}, 'fanart': fanart, 'poster': poster, 'type': 'tvshow', 'contentTitle': title, 'contentType': 'tvshow', 'contentSerieName': title})}",#, 'tmdb_id': tmdb_id})}",#
                    listitem=list_item_streams, 
                    isFolder=True
                )

    if ilist > hasta:
        next_page = page + 1
        
        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=coral]>> Página siguiente[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        #poster = translatePath("special://home/addons/script.module.ModMax/icon.png")
        poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]Siguiente página[/COLOR]')
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'search_com', 'next_page': next_page, 'query_net': query_net})}",
            listitem=list_item_streams, 
            isFolder=True
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)
    

def search(params):
    
    query = params.get('query', '')
    if not query:
        
        last_search = getSetting("last_search")
        query = xbmcgui.Dialog().input("Introduce el título que quieres buscar", defaultt=last_search, type=xbmcgui.INPUT_ALPHANUM)
    
    query_net = normalizar(query)
    params = {}
    params['query_net'] = query_net
    if query_net == '':
        time.sleep(1)
        return mainlist()#search(params)#
    xbmcaddon.Addon().setSetting("last_search", query_net)
    
    try:
        
        search_type = params.get('search_type', '')
        if search_type == 'tvshow':
            return search_tvshow(params)
        elif search_type == 'movie':
            return year_saga_search(params)
        else:
            return search_com(params)
            
    except:#else:#except:
        import sys
        for line in sys.exc_info():
            None#logger.error("%s" % line)
        return []


def selection(params):

    next_page = params.get('next_page', '')
    if next_page: 
        page = int(next_page)
    else:
        page = 0
    
    com = 'Estreno'

    try:
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            data = last.read()
        if not data:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                data = last.read()
    except:
        check_update_titles()
        last_xml = os.path.join(data_path_fix_max, 'last.xml')
        with open (last_xml, 'r', encoding='utf-8') as last:
            data = last.read()
        if not data:
            check_update_titles()
            last_xml = os.path.join(data_path_fix_max, 'last.xml')
            with open (last_xml, 'r', encoding='utf-8') as last:
                data = last.read()
        
    data = re.sub(r"\n|\r|\t|<b>|\s{2}|&nbsp;", "", data)

    patron = r'<item.*?<title>([^<]+)</.*?<micro(.*?)<thumbnail>([^<]+)</.*?<fanart>' \
             r'([^<]+)</.*?<date>([^<]+)</.*?<extra>([^<]+)</.*?<info>([^<]+)</'
    matches = re.compile(patron, re.DOTALL).findall(data)

    desde = page * perpage
    hasta = desde + perpage
    ilist = 0
    
    for tit, calidades, poster, fanart, year, extra, plot in matches:
        rating = 0
        if 'TYLER RAKE 2' in tit:
            extra = 'NA'
        if normalizar(com).lower() in normalizar(extra).lower():# or item.com == 'last':
            ilist += 1
            if desde < ilist <= hasta:
                title = normalizar(tit)

                cals = qualities(calidades)

                if 'CLASICOS DE DISNEY' in tit or 'EL REY LEON 2' in tit or 'EL REY LEON 3' in tit:
                    cals['SD'] = cals['MicroHD'] #cals = 'SD'
                    del cals['MicroHD'] 

                #if PY3 == False:
                x = cals.keys()
                cal0 = []
                for it in x:
                    cal0.append(it)
                '''else:
                    cal0 = [*cals]'''
                cal0.reverse()

                if 'MARVEL' in tit or 'STAR WARS' in tit:
                    if '-' in tit:
                        title = title.split('- ')[1].strip() if 'MARVEL' in \
                                                        tit else title.split(' -')[1].strip()
                elif 'DEADPOOL' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()
                elif 'ANIMALES FANTASTICOS' in tit and ':' in tit:
                    title = title.split(': ')[1].strip()
        
                cals_json = cals
                qlt_json = json.dumps(cals_json, ensure_ascii=False)
                qlt_encoded = quote(qlt_json)
                    
                list_item_streams = xbmcgui.ListItem(label=f'{title} [COLOR=grey]({year})[/COLOR] [COLOR=red]{lang}[/COLOR]  [COLOR=limegreen]{ cal0 }[/COLOR]')
            
                tmdb_id = None
                plot_tmdb, year_tmdb, poster_tmdb, fanart_tmdb, rating_tmdb = fetch_tmdb_metadata(title, year, tmdb_id)
                
                if plot_tmdb:
                    if plot_tmdb != None:
                        if plot_tmdb != '':
                            plot = plot_tmdb
                if year_tmdb:
                    year = year_tmdb
                if poster_tmdb:
                    poster = poster_tmdb
                if fanart_tmdb:
                    fanart = fanart_tmdb
                if rating_tmdb:
                    rating = rating_tmdb
    
                iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
                thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
                #fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
                xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
                info_tag = list_item_streams.getVideoInfoTag()
                info_tag.setMediaType('movie')#video')
                info_tag.setTitle(title)
            
                list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
                list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
                list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]{ plot }[/COLOR]')
                list_item_streams.getVideoInfoTag().setFirstAired(year)
                list_item_streams.getVideoInfoTag().setRating(rating)
            
                list_item_streams.setProperty("IsPlayable", "True")
                xbmcplugin.addDirectoryItem(
                    handle=ADDON_HANDLE, 
                    url=f"{sys.argv[0]}?{urlencode({'action': 'findvideos', 'uris': qlt_encoded, 'infoLabels': {'year': year, 'plot': plot}, 'type': 'movie', 'contentTitle': title, 'contentType': 'movie', 'rating': rating})}",
                    listitem=list_item_streams, 
                    isFolder=False
                )

    if ilist > hasta:
        next_page = page + 1
        
        list_item_streams = xbmcgui.ListItem(label=f'[COLOR=coral]>> Página siguiente[/COLOR]')
    
        iconImage = translatePath("special://home/addons/script.module.ModMax/icon.png")
        thumbnail = translatePath("special://home/addons/script.module.ModMax/icon.png")
        fanart = translatePath("special://home/addons/script.module.ModMax/fanart.jpg")
        #poster = translatePath("special://home/addons/script.module.ModMax/icon.png")
        poster = "https://github.com/pepemebe/mag/raw/main/img/timg/thumb.jpg"
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
            
        list_item_streams.setArt({'thumb': thumbnail,'fanart': fanart, 'poster': poster, 'icon': iconImage})
        list_item_streams.addContextMenuItems([ ('Recargar', 'Container.Refresh') ], replaceItems=True)
        list_item_streams.getVideoInfoTag().setPlot(f'[COLOR=cyan]Siguiente página[/COLOR]')
        
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE, 
            url=f"{sys.argv[0]}?{urlencode({'action': 'selection', 'next_page': next_page})}",
            listitem=list_item_streams, 
            isFolder=True
        )

    return xbmcplugin.endOfDirectory(ADDON_HANDLE)


def fetch_tmdb_metadata(title, year='', tmdb_id=False):
    
    TMDB_BASE_URL = 'https://api.themoviedb.org/3'
    TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p'
    TMDB_API_KEY = 'a1ab8b8669da03637a4b98fa39c39228' #Balandro_TMDB_API_KEY='a1ab8b8669da03637a4b98fa39c39228'
    data_type = 'movie'
    
    if not TMDB_API_KEY:
        return '', '', None, None, 0 #None, None, None, None, None
    
    cache_key = get_cache_key(data_type, title, year)#, season, episode)
    cached = get_from_cache(cache_key)
    if cached:
        synopsis = cached.get('synopsis', '')
        release_year = cached.get('year', '')
        poster = cached.get('poster')
        fanart = cached.get('fanart')
        rating = cached.get('rating', 0)
        
        return synopsis, release_year, poster, fanart, rating
    
    try:#if TMDB_API_KEY:#try:#
        # Construir query de búsqueda
        if not tmdb_id:
            query_params = {
                'api_key': TMDB_API_KEY,
                'query': title,
                'language': 'es-ES'
            }
            if year:
                query_params['year'] = year
        
            search_url = TMDB_BASE_URL + '/search/movie?' + urllib.parse.urlencode(query_params)
            response = urllib.request.urlopen(search_url)
            data = json.loads(response.read().decode('utf-8'))
        
            if not data.get('results'):
                return None, None, None, None, None
        
            else:
                movie_id = data['results'][0]['id']
                
        else:
            movie_id = tmdb_id
        
        # Fetch detalles
        details_url = TMDB_BASE_URL + f'/movie/{movie_id}?' + urllib.parse.urlencode({
            'api_key': TMDB_API_KEY,
            'language': 'es-ES'
        })
        #xbmc.log(f'\n\n---------------details_url--------------------> \n\n {details_url} \n\n', xbmc.LOGINFO)
        det_response = urllib.request.urlopen(details_url)
        det_data = json.loads(det_response.read().decode('utf-8'))
        
        synopsis = det_data.get('overview', '')
        release_year = det_data.get('release_date', '')#[:4]
        rating = det_data.get('vote_average', 0)
        
        poster_path = det_data.get('poster_path')
        poster = f"{TMDB_IMAGE_BASE}/w500{poster_path}" if poster_path else ''
        fanart_path = det_data.get('backdrop_path')
        fanart = f"{TMDB_IMAGE_BASE}/original{fanart_path}" if fanart_path else ''
        
        save_to_cache(cache_key, data_type, tmdb_id, title, release_year, synopsis, rating, poster, fanart)
        
        return synopsis, release_year, poster, fanart, rating
    
    except:#else:#except Exception as e:
        #xbmc.log(f"Error fetching TMDB: {str(e)}", xbmc.LOGERROR)
        return '', '', None, None, 0 #None, None, None, None, None


def fetch_tmdb_tv_metadata(title, year='', tmdb_id=False, season=None, episode=None):
    
    TMDB_BASE_URL = 'https://api.themoviedb.org/3'
    TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p'
    TMDB_API_KEY = 'a1ab8b8669da03637a4b98fa39c39228' #Balandro_TMDB_API_KEY='a1ab8b8669da03637a4b98fa39c39228'
    data_type = 'tvshow'
    
    if not TMDB_API_KEY:
        return '', '', None, None, 0 #None, None, None, None, None
    
    cache_key = get_cache_key(data_type, title, year, season, episode)
    cached = get_from_cache(cache_key)
    if cached:
        ###xbmc.log(f'\n\n---------------cached--------------------> \n\n {cache_key} \n\n {cached}', xbmc.LOGINFO)
        synopsis = cached.get('synopsis', '')
        release_year = cached.get('year', '')
        poster = cached.get('poster')
        fanart = cached.get('fanart')
        rating = cached.get('rating', 0)
        
        return synopsis, release_year, poster, fanart, rating
    
    try:#if TMDB_API_KEY:#try:#
        # Construir query de búsqueda
        if not tmdb_id:# or tmdb_id == None:
            query_params = {
                'api_key': TMDB_API_KEY,
                'query': title,
                'language': 'es-ES'
            }
            if year:
                query_params['first_air_date'] = year
        
            search_url = TMDB_BASE_URL + '/search/tv?' + urllib.parse.urlencode(query_params)
            #xbmc.log(f'\n\n---------------search_url--------------------> \n\n {search_url} \n\n', xbmc.LOGINFO)
            response = urllib.request.urlopen(search_url)
            data = json.loads(response.read().decode('utf-8'))
        
            if not data.get('results'):
                return None, None, None, None, None
        
            else:
                movie_id = data['results'][0]['id']
                
        else:
            movie_id = tmdb_id
        
        if season is not None and episode is not None:
            details_url = TMDB_BASE_URL + f'/tv/{movie_id}/season/{season}/episode/{episode}?' + urllib.parse.urlencode({
                'api_key': TMDB_API_KEY,
                'language': 'es-ES'
            })
        
            #xbmc.log(f'\n\n---------------details_url-NoneNone-------------------> \n\n {details_url} \n\n', xbmc.LOGINFO)
            det_response = urllib.request.urlopen(details_url)
            det_data = json.loads(det_response.read().decode('utf-8'))
            
            synopsis = det_data.get('overview', '')
            release_year = det_data.get('air_date', '')#[:4]
            poster_path = det_data.get('still_path')
            fanart_path = None#det_data.get('backdrop_path')
            rating = det_data.get('vote_average', 0)
            
        elif season is not None:
            details_url = TMDB_BASE_URL + f'/tv/{movie_id}/season/{season}?' + urllib.parse.urlencode({
                'api_key': TMDB_API_KEY,
                'language': 'es-ES'
            })
        
            #xbmc.log(f'\n\n---------------details_url-seasonNone-------------------> \n\n {details_url} \n\n', xbmc.LOGINFO)
            det_response = urllib.request.urlopen(details_url)
            det_data = json.loads(det_response.read().decode('utf-8'))
            
            synopsis = det_data.get('overview', '')
            release_year = det_data.get('air_date', '')#[:4]
            poster_path = det_data.get('poster_path')
            fanart_path = None#det_data.get('backdrop_path')
            rating = det_data.get('vote_average', 0)
            
        else:
            details_url = TMDB_BASE_URL + f'/tv/{movie_id}?' + urllib.parse.urlencode({
                'api_key': TMDB_API_KEY,
                'language': 'es-ES'
            })
        
            #xbmc.log(f'\n\n---------------details_url-TrueTrue-------------------> \n\n {details_url} \n\n', xbmc.LOGINFO)
            det_response = urllib.request.urlopen(details_url)
            det_data = json.loads(det_response.read().decode('utf-8'))
            
            synopsis = det_data.get('overview', '')
            release_year = det_data.get('first_air_date', '')#[:4]
            poster_path = det_data.get('poster_path')
            fanart_path = det_data.get('backdrop_path')
            rating = det_data.get('vote_average', 0)
        
        poster = f"{TMDB_IMAGE_BASE}/w500{poster_path}" if poster_path else ''
        fanart = f"{TMDB_IMAGE_BASE}/original{fanart_path}" if fanart_path else ''
        
        save_to_cache(cache_key, data_type, tmdb_id, title, release_year, synopsis, rating, poster, fanart, season, episode)

        return synopsis, release_year, poster, fanart, rating
    
    except:#else:
        #xbmc.log(f"Error fetching TMDB: {str(e)}", xbmc.LOGERROR)
        try:
            fetch_tmdb_metadata(title, year, tmdb_id)
        except:
            return '', '', None, None, 0 #None, None, None, None, None


def clean_expired_cache(verbose=True):
    """
    Elimina todas las entradas cuya fecha de caducidad (expires_at) ya ha pasado.
    Devuelve el número de filas eliminadas (para log o notificación opcional).
    """
    now = time.time()
    
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Borramos las entradas caducadas
        cursor.execute('DELETE FROM tmdb_cache WHERE expires_at < ?', (now,))
        deleted_count = cursor.rowcount
        
        conn.commit()
        
        if verbose:
            if deleted_count > 0:
                #xbmc.log(f"[TMDB Cache] Limpieza: {deleted_count} entradas caducadas eliminadas", xbmc.LOGINFO)
                info = 'Limpiando caché: {deleted_count} entradas purgadas'
                xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', info, xbmcgui.NOTIFICATION_INFO, 5000, False)
            else:
                #xbmc.log("[TMDB Cache] Limpieza: No había entradas caducadas", xbmc.LOGDEBUG)
                info = 'Caché limpia'
                xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', info, xbmcgui.NOTIFICATION_INFO, 5000, False)
        
        return deleted_count
    
    except sqlite3.Error as e:
        if verbose:
            #xbmc.log(f"[TMDB Cache] Error al limpiar caché caducada: {e}", xbmc.LOGERROR)
            info = 'Error al limpiar la caché'
            xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', info, xbmcgui.NOTIFICATION_INFO, 5000, False)
        return 0
    
    finally:
        if conn:
            conn.close()
            
            
def data_reset():
    
    caps_txt = os.path.join(data_path_fix_max, 'caps.txt')

    info = '[B]Restableciendo las BBDD de películas y series[/B]'
    xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', info, xbmcgui.NOTIFICATION_INFO, 5000, False)

    if os.path.exists(caps_txt):
        remove(caps_txt)

    check_update_titles()


def findvideos(params):
    
    client_verbose = getSetting("client_verbose")
    magnet_client = getSetting("magnet_client")
    
    if not client_verbose:
        if 'Horus' in magnet_client:
            notice = '[B]Va a usar [COLOR=deepskyblue]Horus[/COLOR] ([COLOR=orange]AceServe/AceStream[/COLOR]) como cliente.\nSe recomienda [COLOR=deepskyblue]Elementum[/COLOR] para mayor compatibilidad.\n\n¿Cambiar cliente y no volver a mostrar este mensaje?[/B]'#\n [COLOR=orange]·Puedes configurarlo en los Ajustes de[/COLOR] [COLOR=limegreen]ModMax[/COLOR].'
            if xbmcgui.Dialog().yesno(addon_name, notice):
                xbmcaddon.Addon().openSettings()
                
                return findvideos(params)
            
            else:
                pass
    
    qlt_encoded = params.get('uris', '')
    if not qlt_encoded:
        url = params.get('links', '')
        
        #if not qlt_encoded: #links:
        #magnet = f'magnet:?xt=urn:btih:{cals_json[k]}'
        #encoded_magnet = quote(magnet)
            
        if 'Horus' in magnet_client:
            url_tor = f'plugin://script.module.horus?action=play&infohash={url}'
            
        elif 'Elementum' in magnet_client:
            url_tor = f'plugin://plugin.video.elementum/play?uri=magnet:?xt=urn:btih:{url}'
            
            play_item = xbmcgui.ListItem(offscreen=True)
            play_item.setPath(url_tor)
            # Pass the item to the Kodi player.
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
            return
            
        else:
            inf2 = 'Selecciona cliente para [COLOR yellow]Magnets[/COLOR] en Ajustes.'
            return xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', inf2, xbmcgui.NOTIFICATION_INFO, 5000, False)
            #return
        
        xbmc.executebuiltin(f'RunPlugin("{url_tor}")')
        return

    else:
        qlt_json = urllib.parse.unquote(qlt_encoded)
        cals_json_ori = json.loads(qlt_json)
        
        revs = []
        uris = []
        for rev in cals_json_ori.keys():
            revs.append(rev)
            uris.append(cals_json_ori[rev])
        revs.reverse()
        uris.reverse()
        cals_json = {}
        #g = len(revs)
        h = 0
        for r in revs:
            cals_json[r] = uris[h]
            h += 1
        
        #options = []
        #links = []
        links = {}
        
        heading = '[B]Enlaces disponibles en [COLOR yellow]ModMax[/COLOR][/B]'
        
        for k in cals_json: #[uris]:
            
            cal = f'[{k}]'
            magnet = f'magnet:?xt=urn:btih:{cals_json[k]}'
            encoded_magnet = quote(magnet)
            
            if 'Horus' in magnet_client:
                url_tor = f'plugin://script.module.horus?action=play&infohash={cals_json[k]}'
                leg = '[B]- [COLOR deepskyblue]Horus[/COLOR] [COLOR orange](AceServe/AceStream)[/COLOR][/B]'
                
            elif 'Elementum' in magnet_client:
                url_tor = f'plugin://plugin.video.elementum/play?uri={encoded_magnet}'
                leg = '[B]- [COLOR deepskyblue]Elementum[/COLOR][/B]'
                '''
                play_item = xbmcgui.ListItem(offscreen=True)
                play_item.setPath(url_tor)
                # Pass the item to the Kodi player.
                xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
                return
                '''
            else:
                inf2 = 'Selecciona cliente para [COLOR yellow]Magnets[/COLOR] en Ajustes.'
                return xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', inf2, xbmcgui.NOTIFICATION_INFO, 5000, False)
                #return
            
            #links.append(url_tor)
            
            enlist = f'[B]Magnet [COLOR=limegreen]{cal}[/COLOR][/B]'
            links[enlist] = url_tor
            
            #options.append(enlist)
               
        #if len(options) == 1:
        if len(links) == 1:
            if 'Elementum' in magnet_client:
                
                play_item = xbmcgui.ListItem(offscreen=True)
                play_item.setPath(url_tor)
                # Pass the item to the Kodi player.
                xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
                
                return
                
            else:
                
                xbmc.executebuiltin(f'RunPlugin("{url_tor}")')
                
                return #True
                
        #options.reverse()
        #links.reverse()
        #selection = xbmcgui.Dialog().select(f'{heading} {leg}', options)
        opts = []
        for opt in links.keys():
            opts.append(opt)
            uri = links[opt]
        
        selection = xbmcgui.Dialog().select(f'{heading} {leg}', opts)
        
        if selection == -1:
            
            inf1 = 'Cancelando...'
            xbmcgui.Dialog().notification(f'[B][COLOR yellow]{addon_name}[/COLOR][/B]', inf1, xbmcgui.NOTIFICATION_INFO, 3000, False)
            
            return #None
        
        p = 0
        for ki in links.keys():
            val = links[ki]
            if p == selection:
                url_tor = val
                break
            p += 1
            
        if 'Elementum' in magnet_client:
            play_item = xbmcgui.ListItem(offscreen=True)
            play_item.setPath(url_tor)
            # Pass the item to the Kodi player.
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
            return
        else:    
            #xbmc.executebuiltin(f'RunPlugin("{links[selection]}")')
            xbmc.executebuiltin(f'RunPlugin("{url_tor}")') # {links[enlist]}
        
        return 
        

