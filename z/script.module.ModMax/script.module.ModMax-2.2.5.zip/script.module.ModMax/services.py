# -*- coding: utf-8 -*-

import threading, time
import script


def start_check():
    script.checking()

threading.Thread(target=start_check).start()

