# -*- coding: utf-8 -*-

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, tmdb


#host = 'https://www.pelitorrent.com/'
host = 'https://www.torrenflix.com/'

def mainlist(item):
    logger.info()
    itemlist = []
    
    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'all', text_color = 'yellow' ))

    itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis', text_color = 'deepskyblue' ))
    itemlist.append(item.clone( title = 'Series', action = 'mainlist_series', text_color = 'hotpink' ))
    
    return itemlist # mainlist_pelis(item) # 


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', 
                                search_type = 'movie', text_color = 'deepskyblue' ))
    itemlist.append(item.clone( title = 'Catálogo', action = 'list_categ_search', 
                                url = host + 'torrents-peliculas/', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Más vistas', action = 'list_top', url = host, search_type = 'movie' ))
    
    itemlist.append(item.clone( title = 'Por calidad', action = 'calidad', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por género', action = 'generos', search_type = 'movie' ))
    itemlist.append(item.clone( title = 'Por años', action = 'anios', search_type = 'movie' ))
    #itemlist.append(item.clone( title = 'Por letra (A - Z)', action = 'alfabeto', search_type = 'movie' ))

    return itemlist


def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar serie ...', action = 'search', 
                                search_type = 'tvshow', text_color = 'hotpink' ))
    itemlist.append(item.clone( title = 'Catálogo', action = 'list_categ_search', 
                                url = host + 'torrents-series/', search_type = 'tvshow' ))
    itemlist.append(item.clone( title = 'Más vistas', action = 'list_top', url = host, search_type = 'tvshow' ))
    
    itemlist.append(item.clone( title = 'Por años', action = 'anios', search_type = 'tvshow' ))
    #itemlist.append(item.clone( title = 'Por letra (A - Z)', action = 'alfabeto', search_type = 'tvshow' ))

    return itemlist


def generos(item):
    logger.info()
    itemlist = []

    generos = {
        'accion': 'Acción',
        'animacion': 'Animación',
        'aventura': 'Aventura',
        'belica': 'Bélica',
        'ciencia-ficcion': 'Ciencia ficción',
        'comedia': 'Comedia',
        'crimen': 'Crimen',
        'documental': 'Documental',
        'drama': 'Drama',
        'familia': 'Familia',
        'fantasia': 'Fantasía',
        'guerra': 'Guerra',
        'historia': 'Historia',
        'misterio': 'Misterio',
        'musica': 'Música',
        'romance': 'Romance',
        'suspense': 'Suspense',
        'terror': 'Terror',
        'western': 'Western'
        }

    for gen in sorted(generos):
        itemlist.append(item.clone( title=generos[gen], url=host + 'peliculas/' + gen + '/', 
                                    action='list_categ_search' ))

    return itemlist


def anios(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host)
    anios = scrapertools.find_single_match(data, r'Torofilm_movies_annee(.*?)</ul>')
    
    #patron = '(https://www.pelitorrent.com/release/[0-9]{4}/)">([0-9]{4})</a>'
    patron = '(https://www.torrenflix.com/release/[0-9]{4}/)">([0-9]{4})</a>'
    matches = re.compile(patron, re.DOTALL).findall(anios)
    
    for url, anio in matches:
        itemlist.append(item.clone( action='list_categ_search', url=url, title=anio))
    
    return sorted(itemlist, key=lambda i: i.title, reverse=True)


def alfabeto(item):
    logger.info()
    itemlist = []

    for letra in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        url = host + 'letters/%s/' % letra
        if letra == '#':
            url = host + 'letters/0-9/'

        itemlist.append(item.clone( title=letra, url=url , action='list_categ_search' ))

    return itemlist


def calidad(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(host)
    calidades = scrapertools.find_single_match(data, r'Calidad.HD(.*?)</ul>')
    
    #patron = '(https://www.pelitorrent.com/peliculas/[^<]+/)">([^<]+)</a>'
    patron = '(https://www.torrenflix.com/peliculas/[^<]+/)">([^<]+)</a>'
    matches = re.compile(patron, re.DOTALL).findall(calidades)
    
    for url, calidad in matches:
        itemlist.append(item.clone( action='list_categ_search', url=url, title=calidad))
    
    return itemlist


def do_downloadpage(url, post=None, headers=None, raise_weberror=True):
    if not headers:
        headers = {'Referer': host}

    data = httptools.downloadpage(url, post=post, headers=headers, raise_weberror=raise_weberror).data
    
    return data


def detectar_idioma(langs):
    if 'spanish.png' in langs or 'spanish-series.png' in langs:
        return 'Esp'
    elif 'mx.png' in langs:
        return 'Lat'
    elif 'language-73png.png' in langs:
        return 'VOSE'
    else:
        return None


def limpiar_poster(thumbs):
    thumbs = re.sub(r"-[0-9]{3}x[0-9]{3}.jpg", ".jpg", thumbs)

    return thumbs

def list_top(item):
    logger.info()
    itemlist = []

    if item.search_type == 'tvshow':
        #url = 'https://www.pelitorrent.com/wp-admin/admin-ajax.php'
        url = 'https://www.torrenflix.com/wp-admin/admin-ajax.php'
        post = 'action=action_tr_movie_category&limit=10&post=series&cate=all&mode=2'
        data = httptools.downloadpage(url, post=post).data
    else:
        data = do_downloadpage(item.url)

    patron = r'entry-header fg1">.*?"entry-title">([^<]+)<.*?class="year">([0-9]{4})</span>.*?' \
            '<figure>.*?width=".*?src="([^"]+).*?href="([^"]+)'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for title, year, thumbs, url in matches:
        title = title.strip()
        title = re.sub(r"&#038;|&amp;", "&", title)
        
        thumb = limpiar_poster(thumbs)

        if item.search_type == 'tvshow':
            itemlist.append(item.clone( action='seasons', url=url, title=title, thumbnail=thumb, 
                                        contentType='tvshow', contentTitle=title, 
                                        contentSerieName=title, infoLabels={'year': year} ))
        else:
            itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, 
                                        contentType='movie', contentTitle=title, infoLabels={'year': year} ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def list_categ_search(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    patron = r'entry-header">.*?"entry-title">([^<]+).*?<.*?<figure>.*?width=".*?' \
            'src="([^"]+).*?/figure>(.*?)</div>.*?href="([^"]+)"'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for title, thumbs, comp, url in matches:
        title = title.strip()
        title = re.sub(r"&#038;|&amp;", "&", title)
        qlt = scrapertools.find_single_match(comp, r'class="Qlty">([^<]+)</span')
        if not qlt:
            qlt = scrapertools.find_single_match(comp, r'class="post-ql">([^<]+)<').strip()
        langs = scrapertools.find_single_match(comp, r'class="lang"><img loading="lazy" src="([^"]+)"></span')
        if not langs:
            langs = scrapertools.find_single_match(comp, r'class="post-ql">.*?src="([^"]+)"').strip()
        year = scrapertools.find_single_match(comp, r'class="year">([0-9]{4})</span')
        ctype = scrapertools.find_single_match(comp, r'class="watch btn sm">([^<]+)</span')
        
        thumb = limpiar_poster(thumbs)
        lang = detectar_idioma(langs)
        
        if item.search_type == 'movie':
            if 'pelicula' in ctype:
                itemlist.append(item.clone( action='findvideos' , url=url, title=title, thumbnail=thumb, 
                                    languages=lang, qualities=qlt, contentType='movie', 
                                    contentTitle=title, infoLabels={'year': year} ))
        elif item.search_type == 'tvshow':
            if 'Serie' in ctype:
                itemlist.append(item.clone( action='seasons' , url=url, title=title, thumbnail=thumb, 
                                    languages=lang, qualities=qlt, contentType='tvshow', contentSerieName=title, 
                                    contentTitle=title, infoLabels={'year': year} ))
        else:
            if 'pelicula' in ctype:
                act = 'findvideos'
                content = 'movie'
                title = title + '[COLOR=deepskyblue] -Película-[/COLOR]'
            elif 'Serie' in ctype:
                act = 'seasons'
                content = 'tvshow'
                item.contentSerieName=title
                title = title + '[COLOR=hotpink] -Serie-[/COLOR]'
            itemlist.append(item.clone( action=act , url=url, title=title, thumbnail=thumb, 
                                    languages=lang, qualities=qlt, contentType=content, 
                                    contentTitle=title, infoLabels={'year': year} ))

    tmdb.set_infoLabels(itemlist)

    next_page = scrapertools.find_single_match(data, 'href="([^"]+)" >SIGUIENTE</a')
    if next_page:
        itemlist.append(item.clone( title='>> Página siguiente', url=next_page, 
                                    action='list_categ_search', text_color='coral' ))

    return itemlist


def len_seasons(matches):
    logger.info()
    itemlist = []

    for data_post, season in matches:
        len_matches = len(matches)

        #url = 'https://www.pelitorrent.com/wp-admin/admin-ajax.php'
        url = 'https://www.torrenflix.com/wp-admin/admin-ajax.php'
        post = 'action=action_select_season&season=%s&post=%s' % (season, data_post)
        headers = {'Referer': host}
        dat = httptools.downloadpage(url, post=post, headers=headers).data

        patron = r'.*?num-epi">([^<]+).*?'
        matches2 = scrapertools.find_single_match(dat, patron)

        if len(matches2) == 0:
            len_matches -= 1

        len_season = len_matches

    return len_season



def seasons(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    patron = r'class="aa-cnt.sub-menu">(.*?)</ul>'
    bloc = scrapertools.find_single_match(data, patron)

    matches = re.compile(r'data-post="(.*?)" data-season="(.*?)"', re.DOTALL).findall(bloc)

    len_season = len_seasons(matches) # len(matches) # 

    for data_post, season in matches:
        title='Temporada %s' % season

        if len_season == 1:
            platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')
            item.data_post = data_post
            item.season = season
            item.page = 0
            item.contentType = 'season'
            item.contentSeason = season
            itemlist = episodes(item)
            return itemlist

        itemlist.append(item.clone( action='episodes', data_post=data_post, title=title, season=season, 
                                    thumbnail=item.thumbnail, page = 0, contentType = 'season', 
                                    contentSeason = season, text_color='tan' ))

    tmdb.set_infoLabels(itemlist)

    return sorted(itemlist, key=lambda i: i.title) # itemlist


def episodes(item):
    logger.info()
    itemlist = []

    #url = 'https://www.pelitorrent.com/wp-admin/admin-ajax.php'
    url = 'https://www.torrenflix.com/wp-admin/admin-ajax.php'
    post = 'action=action_select_season&season=%s&post=%s' % (item.season, item.data_post)
    headers = {'Referer': host}
    data = httptools.downloadpage(url, post=post, headers=headers).data

    patron = r'loading="lazy".src="([^"]+)".*?num-epi">([^<]+).*?entry-title">([^<]+)<.*?a.href="([^"]+)"'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for thumbs, num_epi, title, url in matches:
        num_epi = title.split('x')[1]
        title = re.sub(r"&#038;|&amp;", "&", title)
        if not 'https:' in thumbs:
            thumbf = 'https:%s' % thumbs
        else:
            thumbf = thumbs
        thumb = limpiar_poster(thumbf)

        if 'noimg' in thumbs:
            url_dat = False
        else:
            dat_url = do_downloadpage(url)
            if 'Descargar Episodio' in dat_url:
                url_dat = True
            else:
                url_dat = False

        if url_dat:
            itemlist.append(item.clone( action='findvideos', url=url, title=title, contentType='episode', 
                                        contentSeason = item.contentSeason, contentEpisodeNumber = num_epi, 
                                        thumbnail=thumb ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    data = do_downloadpage(item.url)
    
    #patronS = r'orrent</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span>.*?href="([^"]+) class'
    patronS = r'</span>.</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span>.*?href="([^"]+) class'
    #patronP = r'orrent</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span>.*?href="([^"]+)" class'
    patronP = r'</span>.</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span>.*?href="([^"]+)" class'
    
    matches = re.compile(patronS, re.DOTALL).findall(data)
    
    if not matches:
        matches = re.compile(patronP, re.DOTALL).findall(data)
        
    if not matches:
        patronFK = r'</span>.Filekas</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span></td>.*?href="([^"]+)".class'
        matches = re.compile(patronFK, re.DOTALL).findall(data)
        if not matches:
            patronFKS = r'</span>.Filekas</td>.*?<td>([^<]+)</td>.*?<span>([^<]+)</span></td>.*?href="([^"]+).class="'
            matches = re.compile(patronFKS, re.DOTALL).findall(data)
            
        for lang, qlt, url in matches:
            url = re.sub(r"&#038;|&amp;", "&", url)
            
            data_final = do_downloadpage(url)
            patron_final = r'href="([^"]+)".id="downloadFile'
            matches_final = re.compile(patron_final, re.DOTALL).findall(data_final)
            
            for match in matches_final:
                url_t = match #scrapertools.find_single_match(data_final, patron_final)
            
                itemlist.append(item.clone( action = 'play', title = '', url = url_t, server = 'torrent',
                                  type = 'server', language = lang, quality = qlt ))
            
        return itemlist

    for lang, qlt, url in matches:
        url = re.sub(r"&#038;|&amp;", "&", url)
        itemlist.append(item.clone( action = 'play', title = '', url = url, server = 'torrent',
                              type = 'server', language = lang, quality = qlt ))

    return itemlist


def search(item, texto):
    logger.info()
    try:
        item.url = host + '?s=' + texto.replace(" ", "+")
        return list_categ_search(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
